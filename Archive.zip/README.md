#Lympha

## What it does

Remove cookies of the specific site.
